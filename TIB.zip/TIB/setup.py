import os
from setuptools import setup
from nvpy import nvpy

setup(
    name = "TIB",
    version = "1.0",
    author = "jahangir",
    author_email = "cpbotha@vxlabs.com",
    description = "Demo of packaging a Python script as DEB",
    license = "BSD",
    url = "https://github.com/cpbotha/nvpy",
    packages=['TIB'],
    entry_points = {
        'gui_scripts' : ['TIB = TIB.TIB:main']
    },
    data_files = [
        ('share/applications/', ['TIB.desktop'])
    ],
    classifiers=[
        "License :: OSI Approved :: BSD License",
    ],
)
